# PromptLab — Prompt Engineering Playground

## Run the website
1. Extract the ZIP file.
2. Open the `promptlab_website` folder.
3. Double-click `index.html` (or right-click and open it in Chrome/Edge).

No installation, server, API key, or internet connection is required.

## Features
- Responsive landing page and prompt engineering technique overview.
- Interactive prompt builder with task, role, context, tone, output format, and length.
- Five prompt construction modes: zero-shot, few-shot, role-based, step-by-step, and structured output.
- Generate, copy, and download prompts.
- Starter prompt library for education, data analytics, and environment.

## Important project scope
This is a front-end educational prototype. It constructs improved prompts; it does not call an AI model or generate AI answers by itself. To add live AI responses later, connect a backend to an AI API and keep the API key on the server (never expose it in browser JavaScript).

## Suggested presentation
1. Introduce prompt engineering and the problem of vague instructions.
2. Explain the five techniques shown on the website.
3. Demonstrate the playground with one task, then change the technique.
4. Show how role, context, and output format change the resulting prompt.
5. Explain current scope and future enhancement: connect to an AI API and evaluate output quality.
